//
//  HomeData.swift
//  ParkingSpotter
//
//  Created by Guneet Singh Lamba on 05/03/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import Foundation
import UIKit

class HomeData{

    

    init(TicketNumber:String,Location:String)
    {
              
    
    }
    
    
}
